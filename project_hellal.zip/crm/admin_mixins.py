# crm/admin_mixins.py

from .models import Customer, Visitor

class CustomerRestrictionMixin:
    def get_restricted_customers(self, user):
        if user.is_superuser:
            return Customer.objects.all()

        if Visitor.objects.filter(visitor=user).exists():
            return Customer.objects.filter(visitor__visitor=user)

        if Visitor.objects.filter(parent=user).exists():
            return Customer.objects.filter(visitor__parent=user)

        return Customer.objects.none()

    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "customer":
            kwargs["queryset"] = self.get_restricted_customers(request.user)
        return super().formfield_for_foreignkey(db_field, request, **kwargs)
