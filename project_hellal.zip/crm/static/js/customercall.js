alert("ok")
document.addEventListener('DOMContentLoaded', function () {
    const resultField = document.querySelector('#id_result');
    const nextCallFieldWrapper = document.querySelector('.form-group.field-next_call_date'); 
    function toggleNextCallDate() {
        if (resultField.value === 'follow_up') {
            nextCallFieldWrapper.style.display = '';
        } else {
            nextCallFieldWrapper.style.display = 'none';
            const input = nextCallFieldWrapper.querySelector('input');
            if (input) input.value = '';  // Clear field if hidden
        }
    }

    if (resultField && nextCallFieldWrapper) {
        nextCallFieldWrapper.style.display = 'none'; // ⬅️ Hide initially
        toggleNextCallDate(); // ⬅️ Also run once on load in case of pre-filled form
        resultField.addEventListener('change', toggleNextCallDate);
    }
});
