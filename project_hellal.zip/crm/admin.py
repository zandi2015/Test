from django.contrib import admin
from django.urls import path
from collections import defaultdict
from django.shortcuts import render
from django.contrib.admin.views.decorators import staff_member_required
from django.utils.html import format_html
from .models import Visitor, Grade, Customer, CustomerCall, Invoice
from django.contrib.auth.models import User, Group
from django.contrib.auth.admin import UserAdmin, GroupAdmin
from django.db.models import OuterRef, Subquery, Sum, Count, IntegerField
from django.db.models.functions import Coalesce
from .admin_mixins import CustomerRestrictionMixin
from django.core.exceptions import PermissionDenied
# Custom view for the page with merged data

def custom_page_view(request):
    user = request.user

    # Start with all visitors unless filtering is needed
    if Visitor.objects.filter(visitor=user).exists():
        # User is a regular visitor
        visitors = Visitor.objects.filter(visitor=user)
    elif Visitor.objects.filter(parent=user).exists():
        # User is a supervisor
        visitors = Visitor.objects.filter(parent=user)
    else:
        # Admin or no relevant role – show all
        visitors = Visitor.objects.all()

    # Restrict customers to those assigned to selected visitors
    customers = Customer.objects.filter(visitor__in=visitors).select_related('visitor')

    total_invoice_amount = Invoice.objects.filter(customer__in=customers).aggregate(
        total=Sum('invoice_amount')
    )['total'] or 0

    # Get all grades, sorted by target for determining "next grade"
    grades = Grade.objects.all().order_by('target')
    grade_data = {
        grade.identifier: {
            'name': grade.name,
            'identifier': grade.identifier,
            'target': grade.target,
            'customer_count': 0,
            'total_invoice': 0,
            'all_target': 0,
            'next_grade_target': None,
        }
        for grade in grades
    }

    # Map grades to their next grade (based on target sorting)
    grade_list = list(grades)
    for i, grade in enumerate(grade_list):
        if i < len(grade_list) - 1:  # Ensure there's a next grade
            next_grade = grade_list[i + 1]
            grade_data[grade.identifier]['next_grade_target'] = next_grade.target
        else:
            grade_data[grade.identifier]['next_grade_target'] = None  # Last grade has no next grade

    # Assign customers to grades, including those with no invoices
    for customer in customers:
        grade = customer.customer_grade()
        if grade and grade.identifier in grade_data:
            data = grade_data[grade.identifier]
            data['customer_count'] += 1
            # Use total_purchase_amount if defined, else 0 (handles no invoices)
            total_purchase = customer.total_purchase_amount() if hasattr(customer, 'total_purchase_amount') else 0
            data['total_invoice'] += total_purchase
            data['all_target'] = data['customer_count'] * (data['next_grade_target'] or 0)

    # Filter grade_stats to include only grades with customers
    grade_stats = [
        data for data in grade_data.values()
        if data['customer_count'] > 0
    ]

    # Sort grade_stats by target amount
    grade_stats = sorted(grade_stats, key=lambda x: x['target'])

    context = {
        'visitors': visitors.select_related('visitor', 'parent'),
        'total_invoice_amount': total_invoice_amount,
        'grade_stats': grade_stats,
    }

    return render(request, 'admin/custom_page.html', context)
# Custom AdminSite
class CustomAdminSite(admin.AdminSite):
    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('custom-page/', 
                 self.admin_view(custom_page_view), 
                 name='custom-page'),
        ]
        return custom_urls + urls

# Instantiate the custom admin site
custom_admin_site = CustomAdminSite(name='custom_admin')

# Custom Grade Filter
class GradeFilter(admin.SimpleListFilter):
    title = 'Grade'
    parameter_name = 'grade'

    def lookups(self, request, model_admin):
        return [
            (grade.identifier, f"{grade.name} ({grade.identifier})")
            for grade in Grade.objects.all()
        ]

    def queryset(self, request, queryset):
        value = self.value()
        if value:
            # Filter customers whose dynamically computed grade matches the selected identifier
            matching_ids = []
            for customer in queryset:
                grade = customer.customer_grade()
                if grade and grade.identifier == value:
                    matching_ids.append(customer.id)
            return queryset.filter(id__in=matching_ids)
        return queryset

# Register Grade with custom_admin_site
class GradeAdmin(admin.ModelAdmin):
    list_display = ('name', 'identifier', 'formatted_target', 'discount')

custom_admin_site.register(Grade, GradeAdmin)

# Register Visitor with custom_admin_site
class VisitorAdmin(admin.ModelAdmin):
    list_display = ('__str__', 'visitor', 'parent','parent_name')
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        user = request.user

        if user.is_superuser:
            # Admin sees all
            return qs

        # Supervisor sees only their assigned visitors
        return qs.filter(parent=user)
custom_admin_site.register(Visitor, VisitorAdmin)

# Register Customer with custom_admin_site
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('__str__', 'last_call_date', 'formatted_total_purchase_amount', 'distance_to_next_target', 'customer_grade','formatted_level_up_date', 'visitor', 'view_calls_button', 'view_invoices_button')
    list_filter = ('visitor', GradeFilter)
    # search_fields = ('customer_name', 'customer_lastname')  # Uncomment if needed

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        user = request.user

        if user.is_superuser:
            return qs  # Admin sees all

        # Check if user is a visitor
        if Visitor.objects.filter(visitor=user).exists():
            return qs.filter(visitor__visitor=user)

        # Check if user is a supervisor
        if Visitor.objects.filter(parent=user).exists():
            return qs.filter(visitor__parent=user)

        return qs.none()  # Others see nothing

    def last_call_date(self, obj):
        return obj.last_call_date()
    last_call_date.short_description = 'Last Call Date'

    def view_calls_button(self, obj):
        url = f"/admin/crm/customercall/?customer__id__exact={obj.id}"
        return format_html(
            '<a class="btn btn-danger" href="{}">Calls</a>',
            url
        )
    view_calls_button.short_description = "Calls"
    view_calls_button.allow_tags = True

    def view_invoices_button(self, obj):
        url = f"/admin/crm/invoice/?customer__id__exact={obj.id}"
        return format_html(
            '<a class="btn btn-info" href="{}">Invoices</a>',
            url
        )
    view_invoices_button.short_description = "Invoices"
    view_invoices_button.allow_tags = True

custom_admin_site.register(Customer, CustomerAdmin)

# Register CustomerCall with custom_admin_site
class CustomerCallAdmin(CustomerRestrictionMixin,admin.ModelAdmin):
    list_display = ('customer', 'call_date', 'result',"highlighted_next_call","formatted_next_call_date")
    list_filter = ('call_date', 'customer')
    search_fields = ('customer__customer_name', 'details')

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        user = request.user

        if user.is_superuser:
            return qs  # Admin sees all

        # User is a visitor
        if Visitor.objects.filter(visitor=user).exists():
            return qs.filter(customer__visitor__visitor=user)

        # User is a supervisor
        if Visitor.objects.filter(parent=user).exists():
            return qs.filter(customer__visitor__parent=user)

        return qs.none()

custom_admin_site.register(CustomerCall, CustomerCallAdmin)

# Register Invoice with custom_admin_site
class InvoiceAdmin(admin.ModelAdmin):
    list_filter = ('invoice_date', 'customer')
    list_display = ('customer', 'invoice_number', 'invoice_date', 'formatted_total_price', 'formatted_invoice_amount')
    list_per_page = 10  # Default is 100; change as 
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        user = request.user

        if user.is_superuser:
            return qs

        # If the user is a visitor
        if Visitor.objects.filter(visitor=user).exists():
            return qs.filter(customer__visitor__visitor=user)

        # If the user is a supervisor
        if Visitor.objects.filter(parent=user).exists():
            return qs.filter(customer__visitor__parent=user)

        return qs.none()
custom_admin_site.register(Invoice, InvoiceAdmin)

# Register User and Group with custom_admin_site
# custom_admin_site.register(User, UserAdmin)
custom_admin_site.register(Group, GroupAdmin)




class RestrictedUserAdmin(UserAdmin):
    def get_fieldsets(self, request, obj=None):
        fieldsets = super().get_fieldsets(request, obj)

        if request.user.is_superuser:
            return fieldsets

        restricted = []
        for name, options in fieldsets:
            if name and name.lower() in ['permissions', 'groups', 'user permissions']:
                continue
            restricted.append((name, options))

        return restricted

    def get_readonly_fields(self, request, obj=None):
        readonly = list(super().get_readonly_fields(request, obj))
        if not request.user.is_superuser:
            # Prevent changing username or is_superuser flags
            readonly += ['is_superuser', 'is_staff', 'user_permissions', 'groups', 'last_login', 'date_joined']
        return readonly

    def get_queryset(self, request):
        qs = super().get_queryset(request)

        if request.user.is_superuser:
            return qs

        if Visitor.objects.filter(visitor=request.user).exists():
            return qs.filter(id=request.user.id)

        if Visitor.objects.filter(parent=request.user).exists():
            visitor_users = Visitor.objects.filter(parent=request.user).values_list('visitor', flat=True)
            return qs.filter(id__in=list(visitor_users) + [request.user.id])

        return qs.filter(id=request.user.id)

    def has_change_permission(self, request, obj=None):
        if request.user.is_superuser:
            return True

        if obj is None or obj.id == request.user.id:
            return True

        if Visitor.objects.filter(parent=request.user, visitor=obj).exists():
            return True

        return False

admin.site.unregister(User)
custom_admin_site.register(User, RestrictedUserAdmin)