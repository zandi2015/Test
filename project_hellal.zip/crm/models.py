from django.db import models
from django.contrib.auth.models import User,AbstractUser, Group, Permission
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
from django.db.models import Sum
from datetime import timedelta
from django.utils.safestring import mark_safe
from django.utils.html import format_html



class Visitor(models.Model):
    visitor_code = models.CharField(_("Visitor Code"), max_length=20, null=True, default="1000")

    visitor = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='as_visitor',  # Changed to avoid clash
        verbose_name="Visitor Username",
        null=True,
        blank=True
    )

    parent = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='as_supervisor',  # Changed to avoid clash
        verbose_name="Supervisor Username",
        null=True,
        blank=True
    )

    def __str__(self):
        visitor_name = self.visitor.get_full_name() if self.visitor else "No visitor"
        return f"{self.visitor_code} - {visitor_name}"

    def parent_name(self):
        parent_name = self.parent.get_full_name() if self.parent else "No parent"
        return f"{parent_name}"


class Grade(models.Model):
    """
    """
    name = models.CharField(_("Grade Name"), max_length=50)
    identifier = models.CharField(
        _("Identifier"), max_length=20, unique=True
    )  # New identifier field
    target = models.DecimalField(
        _("Sales Target"), max_digits=15, decimal_places=0
    )  # Target sales amount
    discount = models.DecimalField(
        _("Discount (%)"),
        max_digits=5,
        decimal_places=2
    )  # Optional discount

    def __str__(self):
        return f"{self.name} ({self.identifier})"

    def formatted_target(self):
        return "{:,}".format(self.target)

class Customer(models.Model):
    """
    Stores customer information.
    """
    customer_code = models.CharField(
        _("Customer Code"), max_length=20, unique=True
    ) 
    customer_name = models.CharField(_("First Name"), max_length=100)
    customer_lastname = models.CharField(_("Last Name"), max_length=100)
    visitor = models.ForeignKey(
        Visitor,
        on_delete=models.SET_NULL,
        related_name="customers",
        blank=True,
        null=True,
        verbose_name=_("Assigned Visitor"),
    ) 

    def __str__(self):
        return f"{self.customer_name} {self.customer_lastname} ({self.customer_code})"

    def get_full_name(self):
        """
        Returns the full name of the customer by combining their first and last name.
        """
        return f"{self.customer_name} {self.customer_lastname}"
    
    def last_call_date(self):
        """
        Returns the date of the most recent call for this customer.
        If no calls exist, returns None.
        """
        last_call = self.customer_calls.order_by('-call_date').first()  # Get the most recent call
        return last_call.call_date if last_call else None

    def total_purchase_amount(self):
        """
        Calculates the total purchase amount for the customer.
        """
        # Use Sum aggregation on the Invoice model to get the total
        total = Invoice.objects.filter(customer=self).aggregate(
            total_amount=Sum('invoice_amount')  # Adjust 'invoice_amount' if needed
        )['total_amount']
        if total is not None:
            return total  # Format the number with commas
        else:
            return 0

    def formatted_total_purchase_amount(self):
        """
        Calculates the total purchase amount for the customer and formats it.
        """
        total = self.total_purchase_amount()
        return f"{total:,}"
    formatted_total_purchase_amount.short_description = _("total purchase amount")

    def customer_grade(self):
        grade = (
            Grade.objects
            .filter(target__lte=self.total_purchase_amount())
            .order_by('-target')
            .first()
        )
        return grade

    def distance_to_next_target(self):
        """
        Calculates the distance to the next sales target for the customer.
        """
        current_grade = self.customer_grade()
        current_grade_target = 0
        if current_grade:
            current_grade_target = current_grade.target
            
        next_grade = Grade.objects.filter(target__gt=current_grade_target).order_by('target').first()
        
        if next_grade:
            distance = next_grade.target - int(self.total_purchase_amount())
            return f"{distance:,}"
        else:
            return None
    def level_up_date(self):
        """
        Calculates the date when the customer achieved their current grade based on invoices.
        Returns None if no grade or no invoices exist.
        """
        current_grade = self.customer_grade()
        if not current_grade:
            return None

        target_amount = current_grade.target
        cumulative_amount = 0
        # Get invoices ordered by date to simulate purchase history
        invoices = Invoice.objects.filter(customer=self).order_by('invoice_date')
        
        for invoice in invoices:
            cumulative_amount += invoice.invoice_amount
            if cumulative_amount >= target_amount:
                return invoice.invoice_date
        return None

    def formatted_level_up_date(self):
        """
        Displays the level up date as 'today', 'yesterday', or the actual date in red.
        """
        level_up_date = self.level_up_date()
        if not level_up_date:
            return None

        today = timezone.now().date()
        yesterday = today - timedelta(days=1)

        if level_up_date == today:
            display_text = "today"
        elif level_up_date == yesterday:
            display_text = "yesterday"
        else:
            display_text = level_up_date.strftime("%Y-%m-%d")

        return mark_safe(f'<span style="color: red;">{display_text}</span>')
    formatted_level_up_date.short_description = _("Level Up Date")




class CustomerCall(models.Model):
    RESULT_CHOICES = [
        ('buy', 'خرید'),
        ('sample', 'ارسال نمونه'),
        ('no_answer', 'عدم پاسخ'),
        ('visit', 'قرار برای ویزیت حضوری'),
        ('brochure', 'ارسال بروشور و کاتالوگ'),
        ('follow_up', 'نیازمند تماس مجدد'),
    ]

    customer = models.ForeignKey(
        Customer,
        on_delete=models.CASCADE,
        related_name='customer_calls',
        verbose_name="Customer"
    )
    call_date = models.DateField(default=timezone.now)
    result = models.CharField(
        max_length=20,
        choices=RESULT_CHOICES,
        verbose_name="Call result",
        null=True,
        blank=True
    )
    details = models.TextField(verbose_name="Call Details")
    next_call_date = models.DateField(
        verbose_name="Next Call Date",
        null=True,
        blank=True
    )

    def __str__(self):
        return f"Call with {self.customer.get_full_name()} on {self.call_date}"

    def highlighted_next_call(self):
        if self.next_call_date:
            return format_html('<img src="/static/admin/img/icon-yes.svg" alt="True">')
        return ''
    highlighted_next_call.short_description = 'Next Call'
    highlighted_next_call.admin_order_field = 'next_call_date'  # Enables sorting

    def formatted_next_call_date(self):
        if not self.next_call_date:
            return ''
        today = timezone.now().date()
        yesterday = today - timedelta(days=1)
        tomorrow = today + timedelta(days=1)

        label = self.next_call_date.strftime('%Y-%m-%d')
        color = ''
        if self.next_call_date < today:
            color = 'red'  # Past due dates
        else:
            color = 'green'  # Today or future dates

        if self.next_call_date == today:
            label = 'Today'
            color = 'green'
        elif self.next_call_date == yesterday:
            label = 'Yesterday'
            color = 'red'
        elif self.next_call_date == tomorrow:
            label = 'Tomorrow'
            color = 'green'
        return format_html(
            '<span style="color: {};">{}</span>',
            color,
            label
        )
    formatted_next_call_date.short_description = 'Next Call Date'
    formatted_next_call_date.admin_order_field = 'next_call_date'

class Invoice(models.Model):
    """
    Represents an invoice.
    """
    customer = models.ForeignKey(
        Customer,
        on_delete=models.CASCADE,
        related_name="invoices",  # ارتباط معکوس از Customer به Invoice
        verbose_name=_("Customer"),
    )
    invoice_number = models.CharField(
        _("Invoice Number"), max_length=50, unique=True
    )  # شماره فاکتور
    invoice_date = models.DateField(_("Invoice Date"))  # تاریخ فاکتور
    product_code = models.CharField(_("Product Code"), max_length=20)  # کد محصول
    product_name = models.CharField(_("Product Name"), max_length=100)  # نام محصول
    quantity = models.PositiveIntegerField(_("Quantity"))  # تعداد
    price = models.DecimalField(_("Price"), max_digits=10, decimal_places=0)  # مبلغ
    total_price = models.DecimalField(
        _("Total"), max_digits=12, decimal_places=0
    )  # جمع
    invoice_amount = models.DecimalField(
        _("Invoice Amount"), max_digits=15, decimal_places=0
    )  # مبلغ فاکتور

    class Meta:
        verbose_name = _("Invoice")
        verbose_name_plural = _("Invoices")

    def formatted_total_price(self):
        return "{:,}".format(self.total_price)
    formatted_total_price.short_description = _("Total Price")
    def formatted_invoice_amount(self):
        return "{:,}".format(self.invoice_amount)
    formatted_invoice_amount.short_description = _("Invoice Amount")
    def __str__(self):
        return self.invoice_number