
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import render
from django.http import HttpResponseForbidden


@staff_member_required
def custom_admin_page(request):
    user = request.user

    # Optional: role-based restriction
    if hasattr(user, 'user_type') and user.user_type not in ['admin', 'supervisor']:
        return HttpResponseForbidden("Access denied.")

    context = {
        "is_admin": user.user_type == "admin",
        "is_supervisor": user.user_type == "supervisor",
        "is_visitor": user.user_type == "visitor",
    }
    return render(request, "admin/custom_admin_page.html", context)




@staff_member_required
def custom_admin_view(request):
    return render(request, 'admin/custom_page.html')


# if user.user_type == 'admin':
#     data = MyModel.objects.all()
# elif user.user_type == 'semi_admin':
#     data = MyModel.objects.filter(visitor=user)
# else:
#     data = None  # Or redirect / deny

# context['data'] = data
